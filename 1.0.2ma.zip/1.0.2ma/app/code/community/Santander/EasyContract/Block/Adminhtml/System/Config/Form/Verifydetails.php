<?php

/**
 * Verifydetails
 *
 * @file Verifydetails.php
 * @author Consid AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-sep-08
 */

class Santander_EasyContract_Block_Adminhtml_System_Config_Form_Verifydetails
    extends Mage_Adminhtml_Block_System_Config_Form_Field
{
    /**
     * Set template
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('santander_easycontract/system/config/verify-details.phtml');
    }
    
    /**
     * Return element html
     *
     * @param  Varien_Data_Form_Element_Abstract $element
     * @return string
     */
    protected function _getElementHtml(\Varien_Data_Form_Element_Abstract $element)
    {
        return $this->_toHtml();
    }
    
    /**
     * Return ajax url for button
     *
     * @return string
     */
    public function getAjaxVerifyDetailsUrl()
    {
        return Mage::helper('adminhtml')->getUrl('adminhtml/adminhtml_easycontract/verifydetails');
    }
    
    /**
     * Generate button html
     *
     * @return string
     */
    public function getButtonHtml()
    {
        $button = $this->getLayout()
            ->createBlock('adminhtml/widget_button')
            ->setData(array(
                'id' => 'easycontract_verifydetails_button',
                'label' => $this->helper('easycontract')->__('Verify user details'),
                'onclick' => 'javascript:verifyUserDetails(); return false;',
            ));
        
        return $button->toHtml();
    }
}
