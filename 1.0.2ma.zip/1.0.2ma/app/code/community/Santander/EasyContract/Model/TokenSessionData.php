<?php

/**
 * TokenSessionData
 *
 * @file TokenSessionData.php
 * @author Consid Ab <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-sep-04
 */

class Santander_EasyContract_Model_TokenSessionData
{
    /**
     * @var \Santander\model\Token 
     */
    public $token;
    
    /**
     * @var int
     */
    public $orderNumber;
}
