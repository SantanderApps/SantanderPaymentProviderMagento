<?php

/**
 * Santander_EasyContract_Model_Connector
 *
 * @file Connector.php
 * @author Consid AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-sep-04
 */

require_once __DIR__ . '/../lib/llapi/src/autoloader.php';

use Santander\base\Config;

class Santander_EasyContract_Model_Connector implements Santander\base\APIConnectorInterface 
{
    private $_storeId;
    private $_code;
    
    public function __construct()
    {
        $this->_storeId = Mage::app()->getStore()->getStoreId();
        $this->_code = Santander_EasyContract_Model_Constants::CODE;
    }
    
    public function getData($configKey)
    {
        switch ($configKey) {
            case Config::CONFIG_KEY_TEST_MODE:
                return $this->_getMode() == Santander_EasyContract_Model_Constants::STATUS_TEST;
                break;
            case Config::CONFIG_KEY_SANDBOX_MODE:
                return $this->_getMode() == Santander_EasyContract_Model_Constants::STATUS_TEST;
                break;
            case Config::CONFIG_KEY_STORE_ID:
                return $this->_getStoreId();
                break;
            case Config::CONFIG_KEY_USERNAME:
                return $this->_getUsername();
                break;
            case Config::CONFIG_KEY_PASSWORD:
                return $this->_getPassword();
                break;
            case Config::CONFIG_KEY_CERTIFICATE:
                return $this->_getCertificate();
                break;
            case Config::CONFIG_KEY_MERCHANT_ID:
                return $this->_getMerchantId();
                break;
            case Config::CONFIG_KEY_LANGUAGE:
                return $this->_getLanguage();
                break;
            case Config::CONFIG_KEY_SITE_EMAIL_ADDRESS:
                return $this->_getSiteMail();
                break;
            case Config::CONFIG_KEY_SITE_NAME:
                return $this->_getSiteName();
                break;
            case Config::CONFIG_KEY_PLATFORM_NAME:
                return $this->_getPlatformName();
                break;
            case Config::CONFIG_KEY_PLATFORM_VERSION:
                return $this->_getPlatformVersion();
                break;
            case Config::CONFIG_KEY_MODULE_VERSION:
                return $this->_getModuleVersion();
                break;
            case Config::CONFIG_KEY_MODULE_INSTALLATION_DATE:
                return $this->_getModuleInstallationDate();
                break;
            case Config::CONFIG_KEY_ENABLE_EXTENDED_LOGGING:
                return $this->_enableExtendedLogging();
                break;
            case Config::CONFIG_KEY_RETURN_URL:
                return $this->_getReturnUrl();
                break;
            case Config::CONFIG_KEY_ACCESS_LOG_EXTERNAL:
                return $this->_getAccessLogExternal();
                break;
        }
    }
    
    private function _getMode() {
        return $this->_getConfigData('environment');
    }
    
    private function _getStoreId() {
        return $this->_getConfigData('store_id');
    }
    
    private function _getUsername() {
        return $this->_getConfigData('username');
    }
    
    private function _getPassword() {
        // Fulhack
        $defaultPassword = 'testbutik1';
        $password = $this->_getConfigData('password');
        if ($password == $defaultPassword) {
            return $password;
        }
        else {
          return Mage::helper('core')->decrypt($this->_getConfigData('password'));  
        }
    }
    
    private function _getCertificate() {
        return;
    }
    
    private function _getMerchantId() {
        return $this->_getConfigData('merchant_id');
    }
    
    private function _getLanguage() {
        return Mage::getStoreConfig('general/locale/code', $this->_storeId);
    }
    
    private function _getSiteMail() {
        return Mage::getStoreConfig('trans_email/ident_general/email', $this->_storeId);
    }
    
    private function _getSiteName() {
        return Mage::app()->getStore()->getName();
    }
    
    private function _getPlatformName() {
        return 'Magento';
    }
    
    private function _getPlatformVersion() {
        return Mage::getVersion();
    }
    
    private function _getModuleVersion() {
        return (string)Mage::getConfig()->getModuleConfig('Santander_EasyContract')->version;
    }
    
    private function _getModuleInstallationDate() {
        return;
    }
    
    private function _enableExtendedLogging() {
        return TRUE;
    }
    
    private function _getReturnUrl() {
        return Mage::getUrl('easycontract/return');
    }
    
    private function _getAccessLogExternal() {
        return $this->_getConfigData('access_log_external');
    }
    
    private function _getConfigData($field) {
        $path = 'payment/' . $this->_code . '/' . $field;
        $value =  Mage::getStoreConfig($path, $this->_storeId);
        return $value;
    }
}
