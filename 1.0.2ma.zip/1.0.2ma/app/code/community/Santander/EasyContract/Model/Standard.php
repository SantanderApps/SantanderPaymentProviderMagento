<?php

/**
 * Santander_EasyContract_Model_Standard
 *
 * @file Standard.php
 * @author Consid AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-sep-03
 */

class Santander_EasyContract_Model_Standard extends Mage_Payment_Model_Method_Abstract
{
    // Payment method code. Used in XML config and Db.
    protected $_code = Santander_EasyContract_Model_Constants::CODE;
    
    // What block should display the payment option the checkout
    protected $_formBlockType = 'easycontract/form';
    
    // What block should be used for the info box in admin (shows custom logo, for example).
    protected $_infoBlockType = 'easycontract/adminhtml_sales_order_view_custom';

    /**
     * Payment Method features
     * @var bool
     */
    protected $_isGateway                   = true;
    protected $_canOrder                    = false;
    protected $_canAuthorize                = false;
    protected $_canCapture                  = false;
    protected $_canCapturePartial           = false;
    protected $_canCaptureOnce              = false;
    protected $_canRefund                   = false;
    protected $_canRefundInvoicePartial     = false;
    protected $_canVoid                     = false;
    protected $_canUseInternal              = false;
    protected $_canUseCheckout              = true;
    protected $_canUseForMultishipping      = false;
    protected $_isInitializeNeeded          = true;
    protected $_canFetchTransactionInfo     = false;
    protected $_canReviewPayment            = false;
    protected $_canCreateBillingAgreement   = false;
    protected $_canManageRecurringProfiles  = false;
    
    public function __construct()
    {
        require_once __DIR__ . '/../lib/init_api.php';
        parent::__construct();
    }
    
    /**
     * @see Mage_Payment_Model_Method_Abstract::initialize
     * @param string $paymentAction
     * @param Varien_Object $stateObject
     */
    public function initialize($paymentAction, $stateObject)
    {
        Mage::log('Santander Easycontract: Called ' . __METHOD__);
        parent::initialize($paymentAction, $stateObject);
        
        if ($paymentAction != 'sale')
            return $this;
        
        $stateObject->setState(Mage_Sales_Model_Order::STATE_PENDING_PAYMENT);
        $stateObject->setStatus(Mage_Sales_Model_Order::STATE_PENDING_PAYMENT);
        $stateObject->setIsNotified(false);
        
        $quote = Mage::getSingleton('checkout/cart')->getQuote();
        $reservedOrderId = $quote->getReservedOrderId();
        $grandTotal = $quote->getGrandTotal();
        
        $token = Santander::$api->getToken($reservedOrderId, $grandTotal);
        
        if (!$token)
            Mage::throwException(Santander::$api->_('An error occured while communicating with Santander Consumer Bank. Try again or choose another payment method.'));
        elseif (!$token->isOk)
            Mage::throwException($token->errorMessage);
        
        $this->getHelper()->writeTokenToSession($token, $reservedOrderId);
        //print_r($this->getHelper()->readTokenSession()); die;
        
        return $this;
    }
    
    /**
     * Return URL to redirect the customer to.
     * Called after 'place order' button is clicked.
     * Called after order is created and saved.
     * @return string
     */
    public function getOrderPlaceRedirectUrl()
    {
        Mage::log('Santander Easycontract: Called ' . __METHOD__);
        return Mage::getUrl('easycontract/standard/redirect',
            array('_secure' => true));
    }
    
    /*public function getCheckoutRedirectUrl()
    {
        return Mage::getUrl('easycontract/standard/redirect',
            array('_secure' => true));
    }*/
    
    /**
     * Get the module helper class object
     * @return Santander_EasyContract_Helper_Data
     */
    public function getHelper()
    {
        return Mage::helper('easycontract');
    }
}
