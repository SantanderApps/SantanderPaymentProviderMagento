<?php

/**
 * @file init_api.php
 * @author Consid AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-sep-04
 */

require_once __DIR__ . '/llapi/src/autoloader.php';

if (!Santander::isRunning()) {
    Santander::run(new Santander_EasyContract_Model_Connector());
}