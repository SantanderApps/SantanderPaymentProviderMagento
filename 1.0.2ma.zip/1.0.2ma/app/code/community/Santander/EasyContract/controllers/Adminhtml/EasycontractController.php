<?php

/**
 * Santander_EasyContract_Adminhtml_Easycontract
 *
 * @file EasycontractController.php
 * @author Consid Ab <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-sep-08
 */

class Santander_EasyContract_Adminhtml_EasycontractController
    extends Mage_Adminhtml_Controller_Action
{
    /**
     * Test connection against Santander webservice
     */
    public function testconnectionAction()
    {
        require_once Mage::getModuleDir('', 'Santander_EasyContract') . '/lib/init_api.php';
        $wsdlConnection = Santander::$api->getTransferInformation();
        $sfConnection = Santander::$api->getTransferInformation('sf');
        $result = '';
        
        if ($wsdlConnection['success']) {
            $result .= '<div class="secSuccess"><p>' . Santander::$api->_('Success! Connected to {host}', array('{host}' => parse_url($wsdlConnection['info']['url'], PHP_URL_HOST))) . '</p></div>';
        }
        else {
            $result .= '<div class="secError">' . Santander::$api->_('<p>Error! Failed to connect to {host}.<br>It may be due to some of the following reasons:</p><ul><li>The server is not available at the moment.</li><li>Your server do not have an outbound Internet connection.</li></ul>', array('{host}' => parse_url($wsdlConnection['info']['url'], PHP_URL_HOST))) . '</div>';
        }
        
        if ($sfConnection['success']) {
            $result .= '<div class="secSuccess"><p>' . Santander::$api->_('Success! Connected to {host}', array('{host}' => parse_url($sfConnection['info']['url'], PHP_URL_HOST))) . '</p></div>';
        }
        else {
            $result .= '<div class="secError">' . Santander::$api->_('<p>Error! Failed to connect to {host}.<br>It may be due to some of the following reasons:</p><ul><li>The server is not available at the moment.</li><li>Your server do not have an outbound Internet connection.</li></ul>', array('{host}' => parse_url($sfConnection['info']['url'], PHP_URL_HOST))) . '</div>';
        }
        
        Mage::app()->getResponse()->setBody($result);
    }
    
    /**
     * Verify user details
     */
    public function verifydetailsAction()
    {
        require_once Mage::getModuleDir('', 'Santander_EasyContract') . '/lib/init_api.php';
        
        if (Santander::$api->testConnection(uniqid())) {
            $result = '<div class="secSuccess"><p>' .Santander::$api->_('Success! The test connection with the web service works great. Your account details is correct.') . '</p></div>';
        }
        else {
            $result = '<div class="secError"><p>' . Santander::$api->_('Error! The test connection with the web service failed. It seems like your account details are incorrect. Make sure that they are correct, if it still doesn\'t work please {contactUs}.', array('contactUs' => '<a href="' . Santander::$api->config->getClientSiteUrl() . '" target="_blank"><u>contact us</u></a>')) . '</p></div>';
        }
        
        Mage::app()->getResponse()->setBody($result);
    }
}
