<?php

/**
 * ReturnController
 *
 * @file ReturnController.php
 * @author Söderlind Media
 * @version 1.0.0
 * @created 2015-sep-07
 */
class Santander_EasyContract_ReturnController extends Mage_Core_Controller_Front_Action
{
    /**
     * @route easycontract/return
     * @return null
     */
    public function indexAction()
    {
        Mage::log('Santander EasyContract: Called ' . __METHOD__);
        
        require_once dirname(__DIR__) . '/lib/init_api.php';
        
        /* @var $sessionData Santander_EasyContract_Model_TokenSessionData */
        $sessionData = $this->getHelper()->readTokenSession();
        
        if (!$sessionData) {
            $this->_redirect('checkout/cart');
            return;
        }
        
        if (!$this->doesTokenMatchWithQueryString($sessionData->token->token)) {
            Mage::log('Santander EasyContract: Session token and query token do not match.', Zend_Log::WARN);
            $this->_redirect('checkout/cart');
            return;
        }
        
        $result = Santander::$api->getResult($sessionData->token->token, $sessionData->orderNumber);
        
        // Fetch Magentos order object using the "order id-token" pair  in session
        // Order _should_ always be found. But someone might have deleted the 
        // order in admin.
        /* @var $order Mage_Sales_Model_Order */
        $order = $this->getOrderFromSessionData($sessionData);
        
        if (isset($result) && $result->isOk) {
            Mage::log('Santander EasyContract: Got result from webservice.', Zend_Log::NOTICE);
            
            if ($order) {
                $config = $this->getHelper()->getConfig();
                
                $order->setState(
                    $config->module->getOrderStatusAfterPayment(),
                    true,
                    Santander::$api->_('The customer was redirected from Santander Consumer Bank\'s web site back to the shop.') . "\n" .
                    Santander::$api->_('Santander Consumer Bank order number: {orderNumber}', array('orderNumber' => $sessionData->orderNumber)) . "\n" .
                    Santander::$api->_('Authorization receipt to be used when capturing the amount from your payment service provider: {authorizationCode}', array('authorizationCode' => $result->authorizationCode))
                );
                $order->save();
                
                $this->updateShippingAddress($order, $result);
                
                // Magentos's OnepageController->success() looks after these items in the session:
                // - lastSuccessQuoteId
                // - lastQuoteId
                // - lastOrderId
                // If it finds it, it displays a "Thank you for your order" page. Else it displays a "Your cart is emtpy" page.
                // Also see Mage_Checkout_Block_Onepage_Success->_prepareLastOrder for what is needed for the Thank you page
                // to be populated correctly. View file: \app\design\frontend\X\Y\template\checkout\success.phtml
                $session = Mage::getSingleton('checkout/session');
                $session->setLastSuccessQuoteId($order->getQuoteId());
                $session->setLastQuoteId($order->getQuoteId());
                $session->setLastOrderId($order->getId());
            }
            
            $this->_redirect('checkout/onepage/success');
        } elseif (isset($result) && $result->isAbortedByCustomer) {
            if ($order)
                $this->cancelOrderAndAddComment($order, $result);
            
            $this->addWarningToCustomerView(Santander::$api->_('You canceled the payment at the Santander Consumer Bank web site.'), $result);
            
            // If it is the customer herself that aborts, it might not be sensible to show a page that displays
            // "An error occured in the payment process".
            $this->clearOrderDataFromSession();
            $this->_redirect('checkout/cart');
        } else {
            Mage::log('Santander EasyContract: No result from webservice', Zend_Log::WARN);
            
            if ($order)
                $this->cancelOrderAndAddComment($order, $result);
            
            $this->addWarningToCustomerView(Santander::$api->_('Payment could not be completed.'), $result);
            
            $this->clearOrderDataFromSession();
            $this->_redirect('checkout/onepage/failure');
        }
    }
    
    /**
     * @param string $message
     * @param \Santander\model\Result $result
     */
    private function addWarningToCustomerView($message, $result)
    {
        Mage::getSingleton('core/session')->addWarning($message);

        if ($result->humanFailureMessage)
            Mage::getSingleton('core/session')->addWarning($result->humanFailureMessage);
    }
    
    /**
     * @param Mage_Sales_Model_Order $order
     * @param \Santander\model\Result $result
     */
    private function cancelOrderAndAddComment($order, $result)
    {
        $comment = Santander::$api->_('Payment could not be completed. Result code: {resultCode}.', array('{resultCode}' => $result->geResultCode));

        if ($result->humanFailureMessage) {
            $translated = Santander::$api->_('Message displayed to customer');
            $comment .= " $translated: $result->humanFailureMessage.";
        }

        $order->addStatusHistoryComment($comment, false);
        $order->cancel();
        $order->save();
    }
    
    /**
     * Updates the shipping adress for the order with data from Santander's web service (returned by GetResult())
     * @param Mage_Sales_Model_Order $order
     * @param \Santander\model\Result $result
     */
    private function updateShippingAddress($order, $result)
    {
        if ($result->address != null && !empty($result->address->firstName)) {
            $data = $result->address;
            $address = $order->getShippingAddress();

            if ($address && $address->getId()) {
                $address->setFirstname($data->firstName);
                $address->setLastname($data->lastName);
                $address->setCity($data->city);
                $address->setPostcode($data->postCode);
                $address->setStreet($data->address);
                $address->unsetData('street2');
                $address->unsetData('street3');
                $address->unsetData('street4');
                $address->save();
            }
        }
    }
    
    /**
     * Mainly for housekeeping, so that this order doesn't linger in session after the order flow has been completed.
     */
    private function clearOrderDataFromSession()
    {
        $session = Mage::getSingleton('checkout/session');
        $session->clear(); // quoteId, lastSuccessQuoteId
        $session->setLastOrderId(null);
        $session->setLastQuoteId(null);
        $session->setLastRealOrderId(null);
        $this->getHelper()->clearTokenSessionData();
    }
    
    /**
     * Compares token in session with token in queryString
     * @param string $sessionToken
     * @return bool
     */
    private function doesTokenMatchWithQueryString($sessionToken)
    {
        if (!$sessionToken)
            return false;

        return $sessionToken == $this->getTokenFromQuery();
    }

    private function getTokenFromQuery()
    {
        // Token needs to be url fetched in the raw format, since it is decoded automatically if you use Magento or $_GET
        // Example: notice %2b
        // 1. Call to GetToken() might result in: cLG%2blD5fFSJGc ...
        // 2. User is redirected to GE's web site
        // 3. User is returned with someurl.com/?token=cLG%2blD5fFSJGc ...
        // 4.1 When parameter is read by Magento it is returned (urldecoded) as cLG+lD5fFSJGc
        // 4.2 if string from 4.1 is urlencoded the + character is encoded to %2B ( = B instead of b)

        $token = $this->getHelper()->getRawQueryParameter('token');

        if (!$token)
            $token = $this->getHelper()->getRawQueryParameter('Token');

        return $token;
    }

    /**
     * @param Santander_EasyContract_Model_TokenSessionData $sessionData 
     * @return Mage_Sales_Model_Order|null
     */
    private function getOrderFromSessionData($sessionData)
    {
        if ($sessionData->orderNumber) {
            $order = Mage::getModel('sales/order')->loadByIncrementId($sessionData->orderNumber);

            if ($order && $order->getId())
                return $order;
        }

        return null;
    }
    
    /**
     * Get the module helper class object
     * @return Santander_EasyContract_Helper_Data
     */
    public function getHelper()
    {
        return Mage::helper('easycontract');
    }
}
