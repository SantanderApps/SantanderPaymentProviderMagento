<?php

/**
 * Santander_EasyContract_StandardController
 *
 * @file Santander_EasyContract_StandardController.php
 * @author Consid Ab <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-sep-07
 */

class Santander_EasyContract_StandardController extends Mage_Core_Controller_Front_Action
{
    public function redirectAction()
    {
        require_once __DIR__ . '/../lib/init_api.php';
        
        Mage::log('Santander Easycontract: Called ' . __METHOD__);
        $order = $this->getOrder();
        
        if (!$order)
            return;
        
        /* @var $sessionData Santander_EasyContract_Model_TokenSessionData */
        $sessionData = $this->getHelper()->readTokenSession();
        
        if (!$sessionData) {
            // Santander_EasyContract_Model_Standard->initialize() is expected 
            // to have handled the reason for this and sent out notifications to 
            // the store owner.
            $this->cancelOrderAndDisplayWarningToCustomer();
            return;
        }
        
        if ($order->getIncrementId() != $sessionData->orderNumber) {
            $this->cancelOrderAndDisplayWarningToCustomer($sessionData->token->token, $order);
        }
        
        $this->redirectCustomerToSantander($sessionData->token->token, $order);
    }
    
    /**
     * Get the customer's order.
     * @return Mage_Sales_Model_Order|null
     */
    private function getOrder()
    {
        try {
            // Set by Magento when order was placed after last checkout step.
            $incrementId = Mage::getSingleton('checkout/session')->getLastRealOrderId();
            
            if ($incrementId) {
                $order = Mage::getModel('sales/order')->loadByIncrementId($incrementId);
                
                if ($order->getId())
                    return $order;
            }
        } catch (Exception $ex) {
            Mage::logException($e);
        }
        
        // We do not want to display error message to customer, since she might 
        // have come to this url by mistake. (typing it in manually?)
        // Just redirect to empty cart page.
        $this->_redirect('checkout/cart');
        return null;
    }
    
    /**
     * Redirect customer to Santander website
     * @param string $token
     * @param Mage_Sales_Model_Order $order
     */
    private function redirectCustomerToSantander($token, $order)
    {
        try {
            $config = $this->getHelper()->getConfig();
            $redirectUrl = $config->api->getRedirectUrl($token);
            
            $this->getResponse()->setRedirect($redirectUrl);
        } catch (Exception $ex) {
            $this->cancelOrderAndDisplayWarningToCustomer($e);
        }
    }
    
    /**
     * Cancel order and display message to customer.
     * @param type $exception
     */
    private function cancelOrderAndDisplayWarningToCustomer($exception = null)
    {
        if ($exception)
            Mage::logException($exception);
        
        $this->cancelOrder();
        
        Mage::getSingleton('core/session')
            ->addError($this->__('A technical problem occurred when the order was processed. The order has been canceled.'));
        
        $this->_redirect('checkout/cart');
    }
    
    /**
     * Cancel the customer's order
     */
    private function cancelOrder()
    {
        $order = $this->getOrder();
        
        if ($order) {
            try {
                $order->cancel()->save();
            } catch (Exception $ex) {
                Mage::logException($ex);
            }
        }
    }
    
    /**
     * Get the module helper class object
     * @return Santander_EasyContract_Helper_Data
     */
    public function getHelper()
    {
        return Mage::helper('easycontract');
    }
}
