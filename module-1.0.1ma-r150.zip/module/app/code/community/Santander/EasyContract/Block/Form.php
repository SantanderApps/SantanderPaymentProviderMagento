<?php

/**
 * Form
 *
 * @file Form.php
 * @author Consid AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-sep-07
 */

class Santander_EasyContract_Block_Form extends Mage_Payment_Block_Form
{
    public function _construct()
    {
        $this->setTemplate('santander_easycontract/payment-method-form.phtml');
        parent::_construct();
    }
}
