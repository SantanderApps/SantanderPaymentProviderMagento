<?php
    error_reporting(E_ALL);
    
    define('WEB_ROOT', __DIR__);
    
    require __DIR__ . '/../src/autoloader.php';
    require __DIR__ . '/includes/includes.php';
    require __DIR__ . '/../src/Santander.php';
    Santander::run(new Connector()); // Kickstart the API
    
    print Santander::$logger->getLogFile($_GET['d']);
?>