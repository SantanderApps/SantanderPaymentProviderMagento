<?php

/**
 * Santander_EasyContract_Model_Config
 *
 * @file Config.php
 * @author Consid AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-sep-07
 */

class Santander_EasyContract_Model_Config
{
    /**
     * The API configuration
     * @var \Santander\base\Config
     */
    public $api;
    
    /**
     * The module configuration
     * @var Santander_EasyContract_Model_Config 
     */
    public $module;
    
    private $_code = Santander_EasyContract_Model_Constants::CODE;
    
    /**
     * @return string
     */
    public function getOrderStatusAfterPayment()
    {
        return $this->getConfigData('order_status_after_payment');
    }
    
    /**
     * @param string $field config node name defined in system.xml
     * @param null $storeId if not provided, uses current store active in frontend
     * @return string
     */
    private function getConfigData($field, $storeId = null)
    {
        if (null === $storeId)
            $storeId = Mage::app()->getStore()->getStoreId();

        $path = 'payment/'.$this->_code.'/'.$field;

        $value =  Mage::getStoreConfig($path, $storeId);

        return $value;
    }
}
