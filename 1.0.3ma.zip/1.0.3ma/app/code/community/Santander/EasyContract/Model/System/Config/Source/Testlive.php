<?php

/**
 * Testlive
 *
 * @file Testlive.php
 * @author Consid AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-sep-07
 */

class Santander_EasyContract_Model_System_Config_Source_Testlive
{
    public function toOptionArray()
    {
        return array(
            array('value' => Santander_EasyContract_Model_Constants::STATUS_TEST, 'label' => Santander_EasyContract_Model_Constants::STATUS_TEST),
            array('value' => Santander_EasyContract_Model_Constants::STATUS_LIVE, 'label' => Santander_EasyContract_Model_Constants::STATUS_LIVE),
        );
    }
    
    public function toArray()
    {
        return array(
            Santander_EasyContract_Model_Constants::STATUS_TEST => Santander_EasyContract_Model_Constants::STATUS_TEST,
            Santander_EasyContract_Model_Constants::STATUS_LIVE => Santander_EasyContract_Model_Constants::STATUS_LIVE,
        );
    }
}
