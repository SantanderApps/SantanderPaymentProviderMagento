<?php

/**
 * Santander_EasyContract_Model_Constants
 *
 * @file Constants.php
 * @author Consid AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-sep-04
 */

class Santander_EasyContract_Model_Constants
{
    // Environment modes
    const STATUS_TEST = 'test';
    const STATUS_LIVE = 'live';
    
    // Payment gateway code
    const CODE = 'easycontract';
    
    // Token session key
    const TOKEN_SESSION_KEY = 'SANTANDER_TOKEN';
}
