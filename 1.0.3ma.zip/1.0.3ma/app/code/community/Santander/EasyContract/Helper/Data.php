<?php

/**
 * Santander_EasyContract_Helper_Data
 *
 * @file Data.php
 * @author Consid AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-sep-03
 */

class Santander_EasyContract_Helper_Data extends Mage_Core_Helper_Abstract
{
    private $config;
    
    /**
     * Get the API config
     * @return Santander_EasyContract_Model_Config
     */
    public function getConfig()
    {
        if ($this->config == NULL) {
            require_once __DIR__ . '/../lib/init_api.php';
            $config = $this->config = new Santander_EasyContract_Model_Config();
            $this->config->api = Santander::$api->config;
            $this->config->module = $config;
        }
        
        return $this->config;
    }
    
    /**
     * Write a token object to session
     * @param \Santander\model\Token $token
     * @param int $orderNumber
     * @throws Exception
     */
    public function writeTokenToSession($token, $orderNumber)
    {
        $this->getConfig();
        
        if (!$token)
            throw new Exception('Token can not be empty');
        
        if (!$orderNumber)
            throw new Exception('OrderNumber can not be empty');
        
        $data = array(
            'token' => $token,
            'orderNumber' => $orderNumber,
        );
        $data = serialize($data);
        Mage::getSingleton('checkout/session')->setData(Santander_EasyContract_Model_Constants::TOKEN_SESSION_KEY, $data);
    }
    
    /**
     * Read a token from session
     * @return \Santander_EasyContract_Model_TokenSessionData
     */
    public function readTokenSession()
    {
        $this->getConfig();
        
        $sessionData = Mage::getSingleton('checkout/session')->getData(Santander_EasyContract_Model_Constants::TOKEN_SESSION_KEY);
        
        if (!$sessionData)
            return null;
        
        $unserialized = unserialize($sessionData);
        
        if (!$unserialized)
            return null;
        
        $tokenSessionData = new Santander_EasyContract_Model_TokenSessionData();
        $tokenSessionData->token = $unserialized['token'];
        $tokenSessionData->orderNumber = $unserialized['orderNumber'];
        
        return $tokenSessionData;
    }
    
    /**
     * Remove token session
     */
    public function clearTokenSessionData()
    {
        $this->getConfig();
        
        Mage::getSingleton('checkout/session')->setData(Santander_EasyContract_Model_Constants::TOKEN_SESSION_KEY, null);
    }
    
    public function getRawQueryParameter($key)
    {
        $parameters = $this->getRawQueryParameters();

        if (isset($parameters[$key]))
            return $parameters[$key];

        return null;
    }

    private $parameters = null;

    public function getRawQueryParameters()
    {
        if ($this->parameters)
            return $this->parameters;

        $getParameters = array();

        if (isset($_SERVER['QUERY_STRING'])) {
            $queryString = $_SERVER['QUERY_STRING'];

            if (empty($queryString))
                return $getParameters;

            $pairs = explode('&', $queryString);

            foreach($pairs as $pair) {
                $part = explode('=', $pair);

                if (sizeof($part) == 2)
                    $getParameters[$part[0]] = $part[1];
                else if (sizeof($part) == 1)
                    $getParameters[$part[0]] = null;
            }
        }

        $this->parameters = $getParameters;
        return $getParameters;
    }
}
