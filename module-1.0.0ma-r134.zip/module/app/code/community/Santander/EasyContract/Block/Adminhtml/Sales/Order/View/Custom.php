<?php

/**
 * Santander_EasyContract_Block_Adminhtml_Sales_Order_View_Custom
 * 
 * @file Custom.php
 * @author Consid AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-sep-07
 */

class Santander_EasyContract_Block_Adminhtml_Sales_Order_View_Custom extends Mage_Payment_Block_Info
{
    protected function _toHtml()
    {
        /* @var $helper Santander_EasyContract_Helper_Data */
        $helper = Mage::helper('easycontract');
        $config = $helper->getConfig();
        $this->assign('title', Santander::$api->_('Santander Consumer Bank'));
        $this->setTemplate('ge_easycontract/custom.phtml');
        parent::_toHtml();
    }
}